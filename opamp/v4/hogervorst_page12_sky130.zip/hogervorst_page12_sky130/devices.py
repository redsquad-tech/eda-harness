"""Sky130 device helpers for the Hogervorst / Bruschi page-12 op-amp core.

This file deliberately keeps the helpers small and boring.
The world is already chaotic enough without transistor wrappers trying to be clever.

The helpers prefer direct `sky130_hdl21` primitives when that package is installed.
If it is not installed, they fall back to generic HDL21 primitives so the Python modules
can still be imported and netlisted in a process-portable form.
"""

from __future__ import annotations

import hdl21 as h
from hdl21.prefix import µ, p
from hdl21.primitives import Nmos, Pmos, MosVth, R, C

try:
    import sky130_hdl21 as sky130  # type: ignore
    import sky130_hdl21.primitives as sky130p  # type: ignore
except Exception:  # pragma: no cover - import fallback only
    sky130 = None
    sky130p = None


def _sky130_available() -> bool:
    return sky130 is not None and sky130p is not None


# ----------------------------------------------------------------------------
# MOSFET helpers
# ----------------------------------------------------------------------------

def nmos_std(w, l=0.5 * µ, nf: int = 1):
    """Standard-Vt core NMOS."""
    if _sky130_available():
        params = sky130.Sky130MosParams(w=w, l=l, nf=nf)
        return sky130p.NMOS_1p8V_STD(params)
    return Nmos(w=w, l=l, vth=MosVth.STD)



def nmos_low(w, l=0.5 * µ, nf: int = 1):
    """Low-Vt core NMOS. Useful for the rail-to-rail input pair if more gm is needed."""
    if _sky130_available():
        params = sky130.Sky130MosParams(w=w, l=l, nf=nf)
        return sky130p.NMOS_1p8V_LOW(params)
    return Nmos(w=w, l=l, vth=MosVth.LOW)



def pmos_std(w, l=0.5 * µ, nf: int = 1):
    """Standard-Vt core PMOS."""
    if _sky130_available():
        params = sky130.Sky130MosParams(w=w, l=l, nf=nf)
        return sky130p.PMOS_1p8V_STD(params)
    return Pmos(w=w, l=l, vth=MosVth.STD)



def pmos_low(w, l=0.5 * µ, nf: int = 1):
    """Low-Vt core PMOS."""
    if _sky130_available():
        params = sky130.Sky130MosParams(w=w, l=l, nf=nf)
        return sky130p.PMOS_1p8V_LOW(params)
    return Pmos(w=w, l=l, vth=MosVth.LOW)



def pmos_high(w, l=0.5 * µ, nf: int = 1):
    """High-Vt core PMOS."""
    if _sky130_available():
        params = sky130.Sky130MosParams(w=w, l=l, nf=nf)
        return sky130p.PMOS_1p8V_HIGH(params)
    return Pmos(w=w, l=l, vth=MosVth.HIGH)


# ----------------------------------------------------------------------------
# Passive helpers
# ----------------------------------------------------------------------------

def mim_m3(w, l):
    """M3 MiM capacitor.

    Fallback is an ideal capacitor with ~1 fF / µm², only to keep the module importable
    without the sky130 package.
    """
    if _sky130_available():
        params = sky130.Sky130MimCapParams(w=w, l=l)
        return sky130p.MIM_M3(params)
    # Very rough fallback density for process-portable netlisting only.
    return C(c=1.0 * p)



def pp_prec_035(length_um: float):
    """0.35 µm precision poly resistor.

    Sky130 precision-resistor lengths are specified directly in microns.
    The fallback uses an ideal resistor with a very rough 1 kΩ / □ style estimate.
    """
    if _sky130_available():
        params = sky130.Sky130PrecResParams(L=length_um)
        return sky130p.PP_PREC_0p35(params)
    # Crude fallback. The exact value is not the point here.
    return R(r=max(100.0, 1000.0 * length_um))


__all__ = [
    "µ",
    "nmos_std",
    "nmos_low",
    "pmos_std",
    "pmos_low",
    "pmos_high",
    "mim_m3",
    "pp_prec_035",
]
