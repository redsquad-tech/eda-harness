# Hogervorst / Bruschi page-12 core on HDL21 + sky130

This package is the **reworked** version of the op-amp core, with the signal path pulled much closer to the schematic shown on page 12 of the methodology slides.

## What is now intentionally matched to the page-12 figure

- complementary rail-to-rail input stage with **two differential pairs**
- folded-cascode-like first stage producing the two internal gate-drive nodes
  - `VGP`
  - `VGN`
- explicit **Monticelli floating battery** between `VGP` and `VGN`
  - `M24` implemented as the NMOS of the floating battery
  - `M35` implemented as the PMOS of the floating battery
- explicit gate-bias rails
  - `M22-M23` style NMOS diode stack for the gate of `M24`
  - `M33-M34` style PMOS diode stack for the gate of `M35`
- common-source push-pull output stage
- dual `Rc-Cc` compensation branches from `VGP` and `VGN` to `Vout`

## What is deliberately kept outside the core

These are separate blocks on purpose:

- PMOS tail current source for the upper input pair
- NMOS tail current sink for the lower input pair
- PMOS current source feeding the `M24` gate-bias rail
- NMOS current sink feeding the `M35` gate-bias rail
- higher-level NASP blocks: mode logic, auto-zero / calibration storage, daisy-chain test logic, auxiliary switches

That separation is not laziness. It keeps the **core** aligned with the methodology schematic, while letting product-level plumbing sit around it instead of inside it.

## Files

- `devices.py` — sky130 helpers with generic HDL21 fallback
- `generators.py` — elementary blocks: diffpairs, current sources, diode stacks, compensation
- `core_page12.py` — main page-12 core and a small shell that adds separate bias-source blocks

## Notes on fidelity

The core is now **structurally faithful** to the methodology figure:

- first stage -> `VGP` / `VGN`
- floating battery between `VGP` / `VGN`
- diode-stack gate-bias rails
- push-pull output
- two compensation branches

It is still a **starting transistor netlist**, not a signoff-clean final design.
Sizing, bias-current values, common-mode behavior, phase margin, and the exact NASP operating modes still need simulation and iteration.
