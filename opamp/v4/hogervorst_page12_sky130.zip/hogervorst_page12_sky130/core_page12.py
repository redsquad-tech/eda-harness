"""Page-12 Hogervorst / Bruschi high-performance two-stage CMOS op-amp core.

This version is intentionally much closer to the *methodology figure* than the earlier
"architecture-inspired" port:

- rail-to-rail complementary input stage
- folded-cascode first stage with two internal gate-drive nodes: VGP and VGN
- explicit Monticelli floating battery between VGP and VGN
- explicit M22-M23 / M33-M34 style diode stacks for the two gate-bias rails
- push-pull common-source output stage
- dual Rc-Cc compensation branches from VGP/VGN to Vout

What remains outside the core on purpose:
- tail-current generation
- Ibias generation for the Monticelli bias rails
- NASP mode logic, auto-zero storage, daisy-chain test logic, and auxiliary switches

Those are kept as separate blocks, because forcing everything into one netlist blob is how
people end up hating both analog design and each other.
"""

from __future__ import annotations

import hdl21 as h
from hdl21.prefix import µ

from .devices import nmos_std, pmos_high, pmos_low, pmos_std
from .generators import (
    CurrentSourceN,
    CurrentSourceP,
    DiodeStackN,
    DiodeStackP,
    MosGenParams,
    NInputPair,
    PInputPair,
    RcCcComp,
    RcCcParams,
)


@h.paramclass
class Page12CoreParams:
    # Input pairs
    w_in_p = h.Param(dtype=h.Prefixed, desc="PMOS input-pair width", default=8 * µ)
    w_in_n = h.Param(dtype=h.Prefixed, desc="NMOS input-pair width", default=4 * µ)
    l_in = h.Param(dtype=h.Prefixed, desc="Input-pair length", default=0.5 * µ)
    nf_in_p = h.Param(dtype=int, desc="PMOS input-pair fingers", default=2)
    nf_in_n = h.Param(dtype=int, desc="NMOS input-pair fingers", default=2)

    # Folded-cascode first stage
    w_pcas1 = h.Param(dtype=h.Prefixed, desc="Top PMOS folded-cascode width (Vbias1 devices)", default=4 * µ)
    w_pcas2 = h.Param(dtype=h.Prefixed, desc="Second PMOS folded-cascode width (Vbias2 devices)", default=4 * µ)
    w_ncas = h.Param(dtype=h.Prefixed, desc="NMOS folded-cascode width (Vbias3 devices)", default=3 * µ)
    w_nmir = h.Param(dtype=h.Prefixed, desc="Bottom NMOS mirror width", default=3 * µ)
    l_fold = h.Param(dtype=h.Prefixed, desc="Folded-cascode transistor length", default=0.6 * µ)

    # Monticelli floating battery (page-12 M24 / M35)
    w_m24 = h.Param(dtype=h.Prefixed, desc="NMOS floating-battery device width", default=1.5 * µ)
    w_m35 = h.Param(dtype=h.Prefixed, desc="PMOS floating-battery device width", default=3.0 * µ)
    l_mont = h.Param(dtype=h.Prefixed, desc="Monticelli-cell transistor length", default=0.6 * µ)

    # Gate-bias diode stacks (page-12 M22-M23 and M33-M34)
    w_stack_n = h.Param(dtype=h.Prefixed, desc="NMOS diode-stack width", default=1.0 * µ)
    w_stack_p = h.Param(dtype=h.Prefixed, desc="PMOS diode-stack width", default=1.5 * µ)
    l_stack = h.Param(dtype=h.Prefixed, desc="Diode-stack length", default=0.6 * µ)

    # Output stage (page-12 M2 / M1)
    w_out_p = h.Param(dtype=h.Prefixed, desc="PMOS output-device width", default=16 * µ)
    w_out_n = h.Param(dtype=h.Prefixed, desc="NMOS output-device width", default=8 * µ)
    l_out = h.Param(dtype=h.Prefixed, desc="Output-device length", default=0.6 * µ)

    # Compensation
    rcomp_len_um = h.Param(dtype=float, desc="Rc precision-poly length in microns", default=12.0)
    ccomp_w = h.Param(dtype=h.Prefixed, desc="Cc MiM width", default=3 * µ)
    ccomp_l = h.Param(dtype=h.Prefixed, desc="Cc MiM length", default=3 * µ)


@h.generator
def HogervorstPage12Core(params: Page12CoreParams) -> h.Module:
    """Core signal path corresponding to the methodology figure on page 12.

    External bias interface:
    - `tail_p`: common source node of the PMOS input pair, driven by an external PMOS current source
    - `tail_n`: common source node of the NMOS input pair, driven by an external NMOS current sink
    - `vbias1`, `vbias2`, `vbias3`: folded-cascode bias voltages from an external bias block
    - `vb_m24`: left Monticelli gate-bias rail, driven from VDD by an external current source
    - `vb_m35`: right Monticelli gate-bias rail, driven to VSS by an external current sink
    """

    p_pair = PInputPair(
        w=params.w_in_p,
        l=params.l_in,
        nf=params.nf_in_p,
        use_low_vt=True,
    )
    n_pair = NInputPair(
        w=params.w_in_n,
        l=params.l_in,
        nf=params.nf_in_n,
        use_low_vt=True,
    )
    stack_n = DiodeStackN(w=params.w_stack_n, l=params.l_stack, nf=1)
    stack_p = DiodeStackP(w=params.w_stack_p, l=params.l_stack, nf=1, use_high_vt=True)
    comp = RcCcComp(rlen_um=params.rcomp_len_um, c_w=params.ccomp_w, c_l=params.ccomp_l, rsub_to_vss=True)

    @h.module
    class _HogervorstPage12Core:
        # Main ports
        vinp = h.Input()
        vinn = h.Input()
        vout = h.Output()
        VDD = h.Input()
        VSS = h.Input()

        # External bias ports
        tail_p = h.Port(desc="External PMOS tail-current node for the upper input pair")
        tail_n = h.Port(desc="External NMOS tail-current node for the lower input pair")
        vbias1 = h.Input(desc="Upper folded-cascode bias")
        vbias2 = h.Input(desc="Upper signal-path bias")
        vbias3 = h.Input(desc="Lower signal-path bias")
        vb_m24 = h.Port(desc="Left Monticelli gate-bias rail. External current source from VDD connects here.")
        vb_m35 = h.Port(desc="Right Monticelli gate-bias rail. External current sink to VSS connects here.")

        # Optional internal observation nodes. Expose them now, regret later less.
        vgp = h.Output(desc="Upper output-gate drive node")
        vgn = h.Output(desc="Lower output-gate drive node")

        # Internal nodes of the folded-cascode stage
        pnode_l = h.Signal(desc="Upper folded node, reference branch")
        pnode_r = h.Signal(desc="Upper folded node, output branch")
        nnode_l = h.Signal(desc="Lower folded node, reference branch")
        nnode_r = h.Signal(desc="Lower folded node, output branch")
        vref_mid = h.Signal(desc="Reference-branch mid node")

        # ------------------------------------------------------------------
        # Rail-to-rail complementary input stage
        # ------------------------------------------------------------------
        # PMOS input pair, corresponding to the upper differential pair in the methodology figure.
        # Its drains fold downward into the lower NMOS side of the first stage.
        x_pinp = p_pair(dl=nnode_l, dr=nnode_r, gl=vinn, gr=vinp, tail=tail_p, VDD=VDD)

        # NMOS input pair, corresponding to the lower differential pair in the methodology figure.
        # Its drains fold upward into the upper PMOS side of the first stage.
        x_ninp = n_pair(dl=pnode_l, dr=pnode_r, gl=vinp, gr=vinn, tail=tail_n, VSS=VSS)

        # ------------------------------------------------------------------
        # Folded-cascode first stage, page-11 / page-12 style
        # ------------------------------------------------------------------
        # Upper PMOS bias devices (page-11 Vbias1 pair)
        mpb1_l = pmos_high(params.w_pcas1, params.l_fold)(d=pnode_l, g=vbias1, s=VDD, b=VDD)
        mpb1_r = pmos_high(params.w_pcas1, params.l_fold)(d=pnode_r, g=vbias1, s=VDD, b=VDD)

        # Upper signal-path PMOS devices (page-11 Vbias2 pair)
        mpb2_l = pmos_std(params.w_pcas2, params.l_fold)(d=vref_mid, g=vbias2, s=pnode_l, b=VDD)
        mpb2_r = pmos_std(params.w_pcas2, params.l_fold)(d=vgp, g=vbias2, s=pnode_r, b=VDD)

        # Lower signal-path NMOS devices (page-11 / page-12 Vbias3 pair)
        mnb3_l = nmos_std(params.w_ncas, params.l_fold)(d=vref_mid, g=vbias3, s=nnode_l, b=VSS)
        mnb3_r = nmos_std(params.w_ncas, params.l_fold)(d=vgn, g=vbias3, s=nnode_r, b=VSS)

        # Bottom NMOS mirror/sink pair. The left device is diode-connected; the right mirrors it.
        # This is the closest HDL21 translation of the lower mirror shown in the methodology figure.
        mnref = nmos_std(params.w_nmir, params.l_fold)(d=nnode_l, g=nnode_l, s=VSS, b=VSS)
        mnout = nmos_std(params.w_nmir, params.l_fold)(d=nnode_r, g=nnode_l, s=VSS, b=VSS)

        # ------------------------------------------------------------------
        # Explicit Monticelli gate-bias rails from the methodology figure
        # ------------------------------------------------------------------
        # Page-12 text: M22-M23 generate the gate bias for M24.
        x_bias_m24 = stack_n(top=vb_m24, bottom=VSS, VSS=VSS)

        # Page-12 text: M33-M34 generate the gate bias for M35.
        x_bias_m35 = stack_p(top=VDD, bottom=vb_m35, VDD=VDD)

        # ------------------------------------------------------------------
        # Page-12 Monticelli floating battery between VGP and VGN
        # ------------------------------------------------------------------
        # M24 is the NMOS device biased by the M22-M23 rail.
        m24 = nmos_std(params.w_m24, params.l_mont)(d=vgp, g=vb_m24, s=vgn, b=VSS)

        # M35 is the PMOS device biased by the M33-M34 rail.
        m35 = pmos_std(params.w_m35, params.l_mont)(d=vgn, g=vb_m35, s=vgp, b=VDD)

        # ------------------------------------------------------------------
        # Common-source class-AB output stage, page-12 M2 / M1
        # ------------------------------------------------------------------
        m2 = pmos_std(params.w_out_p, params.l_out)(d=vout, g=vgp, s=VDD, b=VDD)
        m1 = nmos_std(params.w_out_n, params.l_out)(d=vout, g=vgn, s=VSS, b=VSS)

        # ------------------------------------------------------------------
        # Dual Rc-Cc compensation branches shown on page 12
        # ------------------------------------------------------------------
        xcomp_p = comp(a=vgp, b=vout, VDD=VDD, VSS=VSS)
        xcomp_n = comp(a=vgn, b=vout, VDD=VDD, VSS=VSS)

    return _HogervorstPage12Core


@h.module
class HogervorstPage12CoreShell:
    """Example shell that adds the *separate* bias-current blocks around the core.

    This is not the full NASP wrapper. It is the small, sane shell around the page-12 core:
    external bias-gate inputs drive four elementary current-source generators.
    """

    vinp = h.Input()
    vinn = h.Input()
    vout = h.Output()
    VDD = h.Input()
    VSS = h.Input()

    # Folded-cascode bias voltages
    vbias1 = h.Input()
    vbias2 = h.Input()
    vbias3 = h.Input()

    # Gate biases for the separate current-source blocks
    vg_tail_p = h.Input(desc="Gate bias for the PMOS input-pair tail-current source")
    vg_tail_n = h.Input(desc="Gate bias for the NMOS input-pair tail-current sink")
    vg_ab_p = h.Input(desc="Gate bias for the PMOS current source feeding vb_m24")
    vg_ab_n = h.Input(desc="Gate bias for the NMOS current sink feeding vb_m35")

    # Optional observation points
    vgp = h.Output()
    vgn = h.Output()

    tail_p, tail_n, vb_m24, vb_m35 = h.Signals(4)

    core = HogervorstPage12Core()( 
        vinp=vinp,
        vinn=vinn,
        vout=vout,
        VDD=VDD,
        VSS=VSS,
        tail_p=tail_p,
        tail_n=tail_n,
        vbias1=vbias1,
        vbias2=vbias2,
        vbias3=vbias3,
        vb_m24=vb_m24,
        vb_m35=vb_m35,
        vgp=vgp,
        vgn=vgn,
    )

    # Separate elementary current-source generators around the core
    itail_p = CurrentSourceP(MosGenParams(w=3 * µ, l=0.8 * µ, nf=1, use_high_vt=True))(d=tail_p, vg=vg_tail_p, VDD=VDD)
    itail_n = CurrentSourceN(MosGenParams(w=2 * µ, l=0.8 * µ, nf=1, use_low_vt=False))(d=tail_n, vg=vg_tail_n, VSS=VSS)
    ibias_p = CurrentSourceP(MosGenParams(w=1.5 * µ, l=1.0 * µ, nf=1, use_high_vt=True))(d=vb_m24, vg=vg_ab_p, VDD=VDD)
    ibias_n = CurrentSourceN(MosGenParams(w=1.0 * µ, l=1.0 * µ, nf=1, use_low_vt=False))(d=vb_m35, vg=vg_ab_n, VSS=VSS)


__all__ = [
    "Page12CoreParams",
    "HogervorstPage12Core",
    "HogervorstPage12CoreShell",
]
