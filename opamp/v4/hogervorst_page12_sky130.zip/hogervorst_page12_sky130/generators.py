"""Elementary generators for the page-12 Hogervorst / Bruschi op-amp core.

These are intentionally small building blocks:
- current sources
- complementary differential pairs
- diode stacks for the Monticelli gate-bias rails
- Rc-Cc compensation cells

The actual core wiring lives in `core_page12.py`.
"""

from __future__ import annotations

import hdl21 as h
from hdl21.prefix import µ

from .devices import (
    µ as _µ,
    mim_m3,
    nmos_low,
    nmos_std,
    pmos_high,
    pmos_low,
    pmos_std,
    pp_prec_035,
)

# Re-export for callers.
µ = _µ


@h.paramclass
class MosGenParams:
    w = h.Param(dtype=h.Prefixed, desc="Width", default=2 * µ)
    l = h.Param(dtype=h.Prefixed, desc="Length", default=0.5 * µ)
    nf = h.Param(dtype=int, desc="Number of fingers", default=1)
    use_low_vt = h.Param(dtype=bool, desc="Use low-Vt flavor when available", default=False)
    use_high_vt = h.Param(dtype=bool, desc="Use high-Vt PMOS when available", default=False)


@h.paramclass
class RcCcParams:
    rlen_um = h.Param(dtype=float, desc="Precision-poly resistor length in microns", default=12.0)
    c_w = h.Param(dtype=h.Prefixed, desc="MiM capacitor width", default=3 * µ)
    c_l = h.Param(dtype=h.Prefixed, desc="MiM capacitor length", default=3 * µ)
    rsub_to_vss = h.Param(dtype=bool, desc="Tie resistor body to VSS when true, else VDD", default=True)


@h.generator
def CurrentSourceP(params: MosGenParams) -> h.Module:
    """Single PMOS current-source transistor.

    Ports:
    - d: current output node
    - vg: bias-gate input
    - VDD: source/bulk supply
    """

    pfet = pmos_high(params.w, params.l, params.nf) if params.use_high_vt else (
        pmos_low(params.w, params.l, params.nf) if params.use_low_vt else pmos_std(params.w, params.l, params.nf)
    )

    @h.module
    class _CurrentSourceP:
        d, vg, VDD = h.Ports(3)
        m = pfet(d=d, g=vg, s=VDD, b=VDD)

    return _CurrentSourceP


@h.generator
def CurrentSourceN(params: MosGenParams) -> h.Module:
    """Single NMOS current-sink transistor.

    Ports:
    - d: current input node
    - vg: bias-gate input
    - VSS: source/bulk supply
    """

    nfet = nmos_low(params.w, params.l, params.nf) if params.use_low_vt else nmos_std(params.w, params.l, params.nf)

    @h.module
    class _CurrentSourceN:
        d, vg, VSS = h.Ports(3)
        m = nfet(d=d, g=vg, s=VSS, b=VSS)

    return _CurrentSourceN


@h.generator
def PInputPair(params: MosGenParams) -> h.Module:
    """PMOS differential pair for the low-common-mode half of the rail-to-rail input stage."""

    pfet = pmos_low(params.w, params.l, params.nf) if params.use_low_vt else pmos_std(params.w, params.l, params.nf)

    @h.module
    class _PInputPair:
        dl, dr, gl, gr, tail, VDD = h.Ports(6)
        ml = pfet(d=dl, g=gl, s=tail, b=VDD)
        mr = pfet(d=dr, g=gr, s=tail, b=VDD)

    return _PInputPair


@h.generator
def NInputPair(params: MosGenParams) -> h.Module:
    """NMOS differential pair for the high-common-mode half of the rail-to-rail input stage."""

    nfet = nmos_low(params.w, params.l, params.nf) if params.use_low_vt else nmos_std(params.w, params.l, params.nf)

    @h.module
    class _NInputPair:
        dl, dr, gl, gr, tail, VSS = h.Ports(6)
        ml = nfet(d=dl, g=gl, s=tail, b=VSS)
        mr = nfet(d=dr, g=gr, s=tail, b=VSS)

    return _NInputPair


@h.generator
def DiodeStackP(params: MosGenParams) -> h.Module:
    """Two stacked diode-connected PMOS devices.

    Used for the page-12 M33-M34 gate-bias rail that biases the PMOS transistor of the
    Monticelli floating battery.
    """

    pfet = pmos_high(params.w, params.l, params.nf) if params.use_high_vt else pmos_std(params.w, params.l, params.nf)

    @h.module
    class _DiodeStackP:
        top, bottom, VDD = h.Ports(3)
        mid = h.Signal()
        # Diode-connected PMOS pair from `top` down to `bottom`
        m1 = pfet(d=mid, g=mid, s=top, b=VDD)
        m2 = pfet(d=bottom, g=bottom, s=mid, b=VDD)

    return _DiodeStackP


@h.generator
def DiodeStackN(params: MosGenParams) -> h.Module:
    """Two stacked diode-connected NMOS devices.

    Used for the page-12 M22-M23 gate-bias rail that biases the NMOS transistor of the
    Monticelli floating battery.
    """

    nfet = nmos_std(params.w, params.l, params.nf)

    @h.module
    class _DiodeStackN:
        top, bottom, VSS = h.Ports(3)
        mid = h.Signal()
        # Diode-connected NMOS pair from `top` down to `bottom`
        m1 = nfet(d=top, g=top, s=mid, b=VSS)
        m2 = nfet(d=mid, g=mid, s=bottom, b=VSS)

    return _DiodeStackN


@h.generator
def RcCcComp(params: RcCcParams) -> h.Module:
    """Series Rc-Cc compensation branch.

    The page-12 schematic shows *two* identical Rc-Cc paths, one from VGP to Vout and one
    from VGN to Vout. This generator gives one branch; the core instantiates it twice.
    """

    @h.module
    class _RcCcComp:
        a, b, VDD, VSS = h.Ports(4)
        nrc = h.Signal()
        rsub = VSS if params.rsub_to_vss else VDD
        r = pp_prec_035(params.rlen_um)(p=a, n=nrc, b=rsub)
        c = mim_m3(params.c_w, params.c_l)(p=nrc, n=b)

    return _RcCcComp


__all__ = [
    "µ",
    "MosGenParams",
    "RcCcParams",
    "CurrentSourceP",
    "CurrentSourceN",
    "PInputPair",
    "NInputPair",
    "DiodeStackP",
    "DiodeStackN",
    "RcCcComp",
]
